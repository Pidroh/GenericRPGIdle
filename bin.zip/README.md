# Generic RPG Idle 

### [Play here!](https://pidroh.github.io/GenericRPGIdle/)

### [Roadmap](https://github.com/Pidroh/HaxeRPGUtilities/wiki)

### [Discord Channel](https://discord.com/invite/AtGrxpM)

### [Steam Page! Wishlist to get updates](https://store.steampowered.com/app/1858120/Generic_RPG_Idle/)

